import { useState, useCallback, useRef, useEffect } from 'react';
import { useAppStore } from '../store/app';
import Button from '../components/ui/Button';
import { Zap } from 'lucide-react';

interface Props {
  gameId: string;
}

type Phase = 'instruction' | 'countdown' | 'playing' | 'complete';

// Cross-browser safe UUID — avoids crypto.randomUUID which isn't available in all mobile browsers
function _uuid(): string {
  if (typeof crypto !== 'undefined' && typeof (crypto as any).randomUUID === 'function') return (crypto as any).randomUUID();
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = (Math.random() * 16) | 0;
    return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
  });
}

interface TargetState {
  x: number;
  y: number;
  spawnTime: number;
  size: number;      // px — shrinks as difficulty increases
  fading?: boolean;  // true = this target fades and vanishes if not tapped quickly enough
}

// Encouragement based on performance
function getEncouragement(hits: number, accuracy: number): string {
  if (hits >= 30 && accuracy >= 80) return 'Lightning fast! You\'re in the zone — your reflexes are incredible!';
  if (hits >= 25 && accuracy >= 70) return 'Solid reaction time! Your brain is responding exactly as it should.';
  if (hits >= 15) return 'Good effort! Every hit trains your neural pathways — keep going!';
  if (accuracy >= 60) return 'You found what you could — missing targets is how your brain learns to focus faster.';
  return 'Every session builds speed. Tomorrow will feel easier than today!';
}

export default function RapidFlashGame({ gameId }: Props) {
  const recordSession = useAppStore(s => s.recordSession);
  
  const containerRef = useRef<HTMLDivElement>(null);
  const timerRef = useRef<number>();
  const targetRef = useRef<TargetState | null>(null);
  const scoreRef = useRef(0);
  const hitsRef = useRef(0);
  const missedRef = useRef(0);
  const livesRef = useRef(3);
  const phaseRef = useRef<Phase>('instruction');
  const startTimeRef = useRef(0);
  const reactionTimesRef = useRef<number[]>([]);
  const gameAreaHeightRef = useRef(0);
  const timerStartedRef = useRef(false);   // timer only starts after first tap
  const isFirstTargetRef = useRef(true);   // first hit = 0 points
  const difficultyLevelRef = useRef(0);    // 0=easy, 1=medium, 2=hard
  const finishGameRef = useRef<() => void>();
  const fadeTimeoutRef = useRef<number>(); // holds timeout id for fading targets
  const spawnCountRef = useRef(0);         // tracks total spawns for zone-bias cycling
  
  const [phase, setPhase] = useState<Phase>('instruction');
  const [target, setTarget] = useState<TargetState | null>(null);
  const [score, setScore] = useState(0);
  const [reactionTimes, setReactionTimes] = useState<number[]>([]);
  const [gameTime, setGameTime] = useState(30);
  const [missed, setMissed] = useState(0);
  const [lives, setLives] = useState(3);
  const [gameAreaHeight, setGameAreaHeight] = useState(0);
  const [difficultyLevel, setDifficultyLevel] = useState(0);
  const [difficultyFlash, setDifficultyFlash] = useState<string | null>(null);

  // Keep refs synced
  useEffect(() => { phaseRef.current = phase; }, [phase]);
  useEffect(() => { gameAreaHeightRef.current = gameAreaHeight; }, [gameAreaHeight]);

  // Scroll to top when game completes so the result screen is always visible
  useEffect(() => {
    if (phase === 'complete' || phase === 'instruction') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [phase]);

  const calcGameAreaHeight = useCallback(() => {
    const vh = window.innerHeight;
    const headerH = 56;
    const statsBarH = 56;
    const hintH = 28;
    const padH = 24;
    return Math.max(Math.min(vh - headerH - statsBarH - hintH - padH - 20, 420), 180);
  }, []);

  // ---- Zone bias system: breaks positional memory by shifting spawn preference ----
  // Every 6 spawns, cycle through: center → top-left → bottom-right → top-right → bottom-left
  const ZONE_BIAS = [
    { cx: 0.5, cy: 0.5, spread: 0.35 },  // center
    { cx: 0.3, cy: 0.3, spread: 0.25 },  // top-left
    { cx: 0.7, cy: 0.7, spread: 0.25 },  // bottom-right
    { cx: 0.7, cy: 0.3, spread: 0.25 },  // top-right
    { cx: 0.3, cy: 0.7, spread: 0.25 },  // bottom-left
  ];
  
  const getCurrentBias = () => ZONE_BIAS[Math.floor(spawnCountRef.current / 6) % ZONE_BIAS.length];

  // ---- Spawn logic without self-reference in deps ----
  const doSpawn = useCallback(() => {
    const container = containerRef.current;
    if (!container || phaseRef.current !== 'playing') return;

    // Clear any pending fade timeout
    if (fadeTimeoutRef.current) clearTimeout(fadeTimeoutRef.current);

    const rect = container.getBoundingClientRect();
    const padMult = [1.0, 0.75, 0.55][difficultyLevelRef.current] ?? 1.0;
    const padding = Math.round(40 * padMult);
    const maxX = rect.width - padding * 2;
    const maxY = rect.height - padding * 2;

    if (maxX <= 0 || maxY <= 0) return;

    // Zone-biased position: keeps player guessing, breaks autopilot
    const bias = getCurrentBias();
    const rawX = rect.width * bias.cx + (Math.random() - 0.5) * rect.width * bias.spread;
    const rawY = rect.height * bias.cy + (Math.random() - 0.5) * rect.height * bias.spread;
    const clampedX = Math.max(padding, Math.min(rect.width - padding, rawX));
    const clampedY = Math.max(padding, Math.min(rect.height - padding, rawY));

    // Smaller base size — starts at ~65px, scales down with difficulty
    const baseSize = Math.min(rect.width, rect.height) * 0.16;
    const sizeMult = [1.0, 0.75, 0.55][difficultyLevelRef.current] ?? 1.0;
    const size = Math.max(Math.round(baseSize * sizeMult), 28);

    // Fade chance scales with difficulty — fades only after timer starts (no cheap misses in warm-up)
    const baseFadeChance = [0.15, 0.35, 0.55][difficultyLevelRef.current] ?? 0.15;
    const fading = !isFirstTargetRef.current && Math.random() < baseFadeChance;

    spawnCountRef.current += 1;
    const newTarget: TargetState = { x: clampedX, y: clampedY, spawnTime: Date.now(), size };
    if (fading) newTarget.fading = true;

    targetRef.current = newTarget;
    setTarget(newTarget);

    // Schedule fade-out if applicable
    if (fading) {
      // Variable fade window: harder difficulties = shorter windows
      const fadeBase = [1000, 700, 450][difficultyLevelRef.current] ?? 1000;
      const fadeJitter = 200; // randomize ±100ms so predictable timing is impossible
      const fadeWindow = fadeBase + (Math.random() * fadeJitter * 2 - fadeJitter);
      
      fadeTimeoutRef.current = window.setTimeout(() => {
        if (targetRef.current === newTarget && phaseRef.current === 'playing') {
          if (timerStartedRef.current) {
            handleMissClick();
          } else {
            // Before timer, just spawn next silently
            targetRef.current = null;
            setTarget(null);
            setTimeout(doSpawn, 100 + Math.random() * 150);
          }
        }
      }, Math.max(fadeWindow, 300));
    }
  }, []); // no self-reference — uses refs for everything mutable

  // Wrapper that calls doSpawn and schedules next with delay
  const spawnNext = useCallback((delayMs: number) => {
    setTimeout(doSpawn, delayMs);
  }, [doSpawn]);

  // Start a target immediately on phase change
  useEffect(() => {
    if (phase === 'playing') {
      doSpawn();
    }
  }, [phase, doSpawn]);

  const handleClick = useCallback((e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (!targetRef.current || phaseRef.current !== 'playing') return;
    
    // Clear any pending fade for this target
    if (fadeTimeoutRef.current) clearTimeout(fadeTimeoutRef.current);
    
    const reactionTime = Date.now() - targetRef.current.spawnTime;
    reactionTimesRef.current = [...reactionTimesRef.current, reactionTime];
    setReactionTimes(reactionTimesRef.current);
    
    // Start the 30s timer on the very first tap
    if (!timerStartedRef.current) {
      timerStartedRef.current = true;
      startTimeRef.current = Date.now();
      timerRef.current = window.setInterval(() => {
        setGameTime(prev => {
          if (prev <= 1) {
            if (timerRef.current) clearInterval(timerRef.current);
            if (finishGameRef.current) finishGameRef.current();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    
    // Update difficulty based on elapsed play time
    const elapsedMs = Date.now() - startTimeRef.current;
    const newDiff = elapsedMs >= 20_000 ? 2 : elapsedMs >= 10_000 ? 1 : 0;
    if (newDiff !== difficultyLevelRef.current) {
      const label = newDiff === 1 ? 'medium' : newDiff === 2 ? 'hard' : null;
      difficultyLevelRef.current = newDiff;
      setDifficultyLevel(newDiff);
      if (label) {
        setDifficultyFlash(label);
        setTimeout(() => setDifficultyFlash(null), 900);
      }
    }
    
    // First target = 0 points, everything else scores normally
    let points = 0;
    if (!isFirstTargetRef.current) {
      const base = Math.max(5, 100 - Math.floor(reactionTime / 15));
      const mult = [1.0, 1.25, 1.6][difficultyLevelRef.current] ?? 1.0;
      points = Math.round(base * mult);
    }
    scoreRef.current += points;
    hitsRef.current += 1;
    isFirstTargetRef.current = false;
    setScore(scoreRef.current);
    
    targetRef.current = null;
    setTarget(null);
    
    // Spawn delay shrinks with difficulty
    const delayBase = [200, 110, 50][difficultyLevelRef.current] ?? 200;
    const delayRange = [150, 110, 80][difficultyLevelRef.current] ?? 150;
    spawnNext(delayBase + Math.random() * delayRange);
  }, [spawnNext]);

  const handleMissClick = useCallback(() => {
    if (targetRef.current || phaseRef.current !== 'playing') return;
    livesRef.current -= 1;
    setLives(livesRef.current);
    missedRef.current += 1;
    setMissed(missedRef.current);
    if (livesRef.current <= 0) {
       finishGameRef.current?.();
    }
  }, []);

  const startGame = useCallback(() => {
    const areaH = calcGameAreaHeight();
    setGameAreaHeight(areaH);
    
    scoreRef.current = 0;
    hitsRef.current = 0;
    missedRef.current = 0;
    livesRef.current = 3;
    targetRef.current = null;
    reactionTimesRef.current = [];
    startTimeRef.current = 0;
    timerStartedRef.current = false;
    isFirstTargetRef.current = true;
    difficultyLevelRef.current = 0;
    spawnCountRef.current = 0;
    
    setScore(0);
    setReactionTimes([]);
    setGameTime(30);
    setMissed(0);
    setLives(3);
    setTarget(null);
    setDifficultyLevel(0);
    setDifficultyFlash(null);
    setPhase('countdown');
    
    setTimeout(() => {
      setPhase('playing');
      phaseRef.current = 'playing';
    }, 1200);
  }, [calcGameAreaHeight]);

  const finishGame = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (fadeTimeoutRef.current) clearTimeout(fadeTimeoutRef.current);
    targetRef.current = null;
    setTarget(null);
    setPhase('complete');
    
    const avgReaction = reactionTimes.length > 0 
      ? Math.round(reactionTimes.reduce((a, b) => a + b, 0) / reactionTimes.length)
      : 0;
    const totalAttempts = hitsRef.current + missedRef.current;
    const accuracy = totalAttempts > 0 ? (hitsRef.current / totalAttempts) * 100 : 0;
    
    recordSession(
      {
        id: _uuid(),
        userId: null,
        gameId,
        score: scoreRef.current,
        accuracy,
        difficultyLevel: 1,
        metrics: { avgReaction, hits: hitsRef.current, misses: missedRef.current, totalAttempts },
      },
      { highScore: Math.max(scoreRef.current, 0), bestAccuracy: accuracy, averageDifficulty: 1 },
    );
  }, [gameId, reactionTimes, recordSession]);

  // Keep finishGameRef in sync
  useEffect(() => {
    finishGameRef.current = finishGame;
  }, [finishGame]);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (fadeTimeoutRef.current) clearTimeout(fadeTimeoutRef.current);
    };
  }, []);

  // Instruction
  if (phase === 'instruction') {
    return (
      <div className="flex flex-col items-center justify-center gap-5 sm:gap-6 animate-fade-in px-4" style={{ minHeight: `${Math.max(window.innerHeight - 56, 400)}px` }}>
        <div className="text-center space-y-3">
          <div className="w-14 h-14 sm:w-20 sm:h-20 mx-auto rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center shadow-xl">
            <Zap className="w-7 h-7 sm:w-10 sm:h-10 text-white" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-amber-600 to-orange-600 dark:from-amber-400 dark:to-orange-400 bg-clip-text text-transparent">
            Rapid Flash
          </h1>
          <p className="text-sm sm:text-base text-slate-600 dark:text-slate-400 max-w-sm leading-relaxed">
            Tap ⚡ targets as fast as you can! Targets shift zones and some fade away — stay alert, don't fall into autopilot!
          </p>
        </div>
        
        <div className="bg-white dark:bg-slate-800 rounded-xl p-4 border border-slate-200 dark:border-slate-700 w-full max-w-xs text-center space-y-2">
          <p className="text-sm text-slate-500 dark:text-slate-400">How it works:</p>
          <div className="text-left text-sm text-slate-600 dark:text-slate-300 space-y-1">
            <p>⚡ Targets appear in shifting zones</p>
            <p>✨ Some targets fade — tap them fast!</p>
            <p>✓ Faster taps earn bonus points</p>
            <p>❌ Tapping blanks costs a life</p>
            <p>⏱️ 30 seconds per run</p>
          </div>
        </div>
        
        <Button size="lg" onClick={startGame} className="w-full max-w-xs">
          Start Test
        </Button>
      </div>
    );
  }

  // Countdown
  if (phase === 'countdown') {
    return (
      <div className="flex items-center justify-center" style={{ minHeight: `${Math.max(window.innerHeight - 56, 400)}px` }}>
        <div className="text-center space-y-4 animate-fade-in">
          <p className="text-7xl font-black text-amber-500 animate-pulse">Go!</p>
          <p className="text-slate-500 dark:text-slate-400 text-lg">Watch for zone shifts!</p>
        </div>
      </div>
    );
  }

  // Complete screen
  if (phase === 'complete') {
    const avgReaction = reactionTimes.length > 0 
      ? Math.round(reactionTimes.reduce((a, b) => a + b, 0) / reactionTimes.length)
      : 0;
    const hits = hitsRef.current;
    const totalAttempts = hits + missedRef.current;
    const accuracy = totalAttempts > 0 ? (hits / totalAttempts) * 100 : 0;
    const msg = getEncouragement(hits, accuracy);

    return (
      <div className="flex flex-col items-center justify-center gap-5 sm:gap-6 animate-fade-in px-4" style={{ minHeight: `${Math.max(window.innerHeight - 56, 400)}px` }}>
        <div className="text-4xl sm:text-5xl mb-1">⚡</div>
        <h2 className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-amber-600 to-orange-600 dark:from-amber-400 dark:to-orange-400 bg-clip-text text-transparent">
          Game Over
        </h2>
        <p className="text-sm sm:text-base text-slate-600 dark:text-slate-400 italic text-center max-w-xs">{msg}</p>
        
        <div className="grid grid-cols-3 gap-2 sm:gap-3 w-full max-w-sm px-2">
          <div className="bg-white dark:bg-slate-800 rounded-xl p-3 sm:p-4 border border-slate-200 dark:border-slate-700 text-center">
            <p className="text-xs text-slate-500 dark:text-slate-400">Score</p>
            <p className="text-xl sm:text-2xl font-bold text-primary-600 dark:text-primary-400">{score}</p>
          </div>
          <div className="bg-white dark:bg-slate-800 rounded-xl p-3 sm:p-4 border border-slate-200 dark:border-slate-700 text-center">
            <p className="text-xs text-slate-500 dark:text-slate-400">Avg Reaction</p>
            <p className="text-sm sm:text-2xl font-bold">{avgReaction} ms</p>
          </div>
          <div className="bg-white dark:bg-slate-800 rounded-xl p-3 sm:p-4 border border-slate-200 dark:border-slate-700 text-center">
            <p className="text-xs text-slate-500 dark:text-slate-400">Accuracy</p>
            <p className="text-xl sm:text-2xl font-bold">{Math.round(accuracy)}%</p>
          </div>
        </div>
        
        <div className="text-center space-y-1 px-4">
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Hits: <span className="font-bold text-emerald-600 dark:text-emerald-400">{hits}</span>
            {' '}· Misses: <span className="font-bold text-red-500">{missed}</span>
          </p>
        </div>
        
        <Button size="lg" onClick={startGame} className="w-full max-w-xs">
          Try Again
        </Button>
      </div>
    );
  }

  // Playing phase
  return (
    <div className="flex flex-col" style={{ minHeight: `${Math.max(window.innerHeight - 56, 400)}px` }}>
      {/* Stats bar */}
      <div className="bg-white dark:bg-slate-800 rounded-2xl mx-2 sm:mx-3 mt-2 p-2 sm:p-3 border border-slate-200 dark:border-slate-700 flex justify-around items-center shrink-0">
        <div className="text-center">
          <p className="text-xs text-slate-500 dark:text-slate-400">Score</p>
          <p className="text-lg sm:text-xl font-bold">{score}</p>
        </div>
        <div className="text-center">
          <p className="text-xs text-slate-500 dark:text-slate-400">Time</p>
          <p className={`text-lg sm:text-xl font-bold ${gameTime <= 10 ? 'text-red-500 animate-pulse' : ''}`}>{gameTime}s</p>
        </div>
        <div className="text-center">
          <p className="text-xs text-slate-500 dark:text-slate-400">Lives</p>
          <p className="text-base sm:text-lg font-bold text-rose-500">{'❤️'.repeat(lives)}{'🖤'.repeat(3 - lives)}</p>
        </div>
        <div className="text-center px-2 py-0.5">
          <span className={`inline-block text-xs font-bold px-2 py-0.5 rounded-full transition-all duration-300 ${
            difficultyLevel === 0 ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400' :
            difficultyLevel === 1 ? 'bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400' :
            'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400 animate-pulse'
          }`}>
            {difficultyLevel === 0 ? 'EASY' : difficultyLevel === 1 ? 'MEDIUM' : 'HARD'}
          </span>
        </div>
      </div>

      {/* Difficulty flash — shows "MEDIUM!" / "HARD!" briefly */}
      {difficultyFlash && (
        <div className="fixed inset-0 z-50 flex items-center justify-center pointer-events-none">
          <div className={`text-4xl sm:text-5xl font-black animate-bounce drop-shadow-lg ${
            difficultyFlash === 'hard'
              ? 'text-red-600 dark:text-red-400'
              : 'text-amber-600 dark:text-amber-400'
          }`}>
            🔥 {difficultyFlash.toUpperCase()}!
          </div>
        </div>
      )}

      {/* Game area */}
      <div
        ref={containerRef}
        onClick={handleMissClick}
        className="relative mx-2 sm:mx-3 mt-2 bg-slate-100 dark:bg-slate-900 rounded-2xl border-2 border-slate-300 dark:border-slate-700 overflow-hidden cursor-crosshair select-none touch-none"
        style={{ height: `${gameAreaHeight}px`, minHeight: '180px' }}
      >
        {target && (
          <button
            onMouseDown={handleClick}
            onTouchStart={(e) => { e.preventDefault(); handleClick(e as unknown as React.MouseEvent); }}
            className={`absolute rounded-full flex items-center justify-center text-white shadow-lg transform transition-transform active:scale-95 touch-manipulation z-10 ${
              target.fading 
                ? 'animate-pulse opacity-75 bg-gradient-to-br from-rose-400 to-red-500' 
                : 'bg-gradient-to-br from-amber-400 to-orange-500 hover:scale-110'
            }`}
            style={{
              left: target.x - target.size / 2,
              top: target.y - target.size / 2,
              width: target.size,
              height: target.size,
              fontSize: `${Math.round(target.size * 0.55)}px`,
            }}
          >
            ⚡
          </button>
        )}
      </div>

      <p className="text-center text-xs text-slate-400 dark:text-slate-500 px-4 pb-2 sm:pb-3 shrink-0 mt-1">
        Watch for zone shifts · Fading targets vanish fast!
      </p>
    </div>
  );
}
