import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { UserStats, SessionRecord } from '../types/game';

export interface DemoPrefs {
  /** Global toggle — when false, never auto-show demos */
  enabled: boolean;
  /** Per-game: has the user completed their first play? */
  firstPlayed: Record<string, boolean>;
  /** Per-game: user explicitly hid the demo for this game */
  suppressed: Record<string, boolean>;
}

export type SyncStatus = 'saved' | 'pending' | 'synced';

interface AppState {
  // Theme
  darkMode: boolean;
  toggleDarkMode: () => void;

  // Current navigation
  currentPage: 'home' | 'games' | 'stats' | 'profile';
  setCurrentPage: (page: 'home' | 'games' | 'stats' | 'profile') => void;
  selectedGameId: string | null;
  setSelectedGameId: (id: string | null) => void;

  // User stats (local)
  userStats: Record<string, UserStats>;
  sessionHistory: SessionRecord[];

  /**
   * Persist a finished game session + update stats atomically.
   * Dedupes by session id so offline retries can't double-count.
   */
  recordSession: (
    record: Omit<SessionRecord, 'id' | 'playedAt'> & { id?: string; playedAt?: string },
    stats: { highScore: number; bestAccuracy: number; averageDifficulty: number },
  ) => { isNewBest: boolean; improvementVsLast: number | null };

  /** Sync status indicator (local-first: 'saved' for guests) */
  syncStatus: SyncStatus;

  // Demo/first-play preferences
  demoPrefs: DemoPrefs;
  setDemoEnabled: (enabled: boolean) => void;
  suppressDemoForGame: (gameId: string, suppressed: boolean) => void;
  markGamePlayed: (gameId: string) => void;
  /** Whether the demo should auto-show right now for this game */
  shouldShowDemo: (gameId: string) => boolean;

  // Guest mode tracking
  isGuest: boolean;
  setAuthenticated: (auth: boolean) => void;

  // Data reset
  resetAllData: () => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      darkMode:
        typeof window !== 'undefined' &&
        window.matchMedia('(prefers-color-scheme: dark)').matches,
      toggleDarkMode: () => set((s) => ({ darkMode: !s.darkMode })),

      currentPage: 'home',
      setCurrentPage: (page) => set({ currentPage: page }),
      selectedGameId: null,
      setSelectedGameId: (id) => set({ selectedGameId: id }),

      userStats: {},
      sessionHistory: [],
      syncStatus: 'saved',
      isGuest: true,

      demoPrefs: {
        enabled: true,
        firstPlayed: {},
        suppressed: {},
      },

      recordSession: (record, stats) => {
        const state = get();
        const id = record.id ?? crypto.randomUUID();

        // Dedupe: if we already have this session id, do not double-count.
        if (state.sessionHistory.some((s) => s.id === id)) {
          return {
            isNewBest: false,
            improvementVsLast: state.userStats[record.gameId]?.lastScore != null
              ? record.score - (state.userStats[record.gameId]?.lastScore ?? 0)
              : null,
          };
        }

        const existing = state.userStats[record.gameId];
        const isNewBest = !existing || record.score > existing.highScore;
        const improvementVsLast =
          existing?.lastScore != null ? record.score - existing.lastScore : null;

        const newStats: UserStats = {
          gameId: record.gameId,
          highScore: Math.max(existing?.highScore ?? 0, record.score),
          bestAccuracy: Math.max(existing?.bestAccuracy ?? 0, stats.bestAccuracy),
          totalPlays: (existing?.totalPlays ?? 0) + 1,
          averageDifficulty:
            ((existing?.averageDifficulty ?? 0) * (existing?.totalPlays ?? 0) +
              stats.averageDifficulty) /
            ((existing?.totalPlays ?? 0) + 1),
          lastScore: record.score,
          lastPlayedAt: record.playedAt ?? new Date().toISOString(),
        };

        set((s) => ({
          sessionHistory: [{ ...record, id, playedAt: record.playedAt ?? new Date().toISOString() }, ...s.sessionHistory].slice(0, 200),
          userStats: { ...s.userStats, [record.gameId]: newStats },
          demoPrefs: {
            ...s.demoPrefs,
            firstPlayed: { ...s.demoPrefs.firstPlayed, [record.gameId]: true },
          },
          syncStatus: s.isGuest ? 'saved' : 'pending',
        }));

        // Guest/local persistence is the source of truth; mark synced shortly after
        // so the UI can flash a subtle "Saved" state.
        setTimeout(() => {
          set((s) => ({ syncStatus: s.isGuest ? 'saved' : 'synced' }));
        }, 800);

        return { isNewBest, improvementVsLast };
      },

      setDemoEnabled: (enabled) =>
        set((s) => ({ demoPrefs: { ...s.demoPrefs, enabled } })),

      suppressDemoForGame: (gameId, suppressed) =>
        set((s) => ({
          demoPrefs: {
            ...s.demoPrefs,
            suppressed: { ...s.demoPrefs.suppressed, [gameId]: suppressed },
          },
        })),

      markGamePlayed: (gameId) =>
        set((s) => ({
          demoPrefs: {
            ...s.demoPrefs,
            firstPlayed: { ...s.demoPrefs.firstPlayed, [gameId]: true },
          },
        })),

      shouldShowDemo: (gameId) => {
        const { demoPrefs } = get();
        if (!demoPrefs.enabled) return false;
        if (demoPrefs.suppressed[gameId]) return false;
        return !demoPrefs.firstPlayed[gameId];
      },

      setAuthenticated: (auth) => set({ isGuest: !auth }),

      resetAllData: () =>
        set({
          userStats: {},
          sessionHistory: [],
          demoPrefs: { enabled: true, firstPlayed: {}, suppressed: {} },
          syncStatus: 'saved',
        }),
    }),
    {
      name: 'cognitive-pulse-storage',
      partialize: (state) => ({
        darkMode: state.darkMode,
        userStats: state.userStats,
        sessionHistory: state.sessionHistory,
        isGuest: state.isGuest,
        demoPrefs: state.demoPrefs,
      }),
    },
  ),
);
