import { useParams, Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { GAMES } from '../data/games';
import DigitSpanGame from '../games/DigitSpanGame';
import SpatialMatrixGame from '../games/SpatialMatrixGame';
import CardPairsGame from '../games/CardPairsGame';
import StroopGame from '../games/StroopGame';
import ObjectLocationGame from '../games/ObjectLocationGame';
import RapidFlashGame from '../games/RapidFlashGame';
import { useState, useEffect } from 'react';

interface GameComponentProps {
  gameId: string;
}

const GAME_COMPONENTS: Record<string, React.FC<GameComponentProps>> = {
  'digit-span': DigitSpanGame,
  'spatial-matrix': SpatialMatrixGame,
  'card-pairs': CardPairsGame,
  'stroop': StroopGame,
  'object-location': ObjectLocationGame,
  'rapid-flash': RapidFlashGame,
};

export default function GamePlay() {
  const { gameId } = useParams<{ gameId: string }>();
  const [showBackButton, setShowBackButton] = useState(false);
  const game = GAMES.find(g => g.slug === gameId);
  
  // Scroll to top when component mounts
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [gameId]);

  useEffect(() => {
    const handleScroll = () => {
      // Show back button after scrolling down 50px
      setShowBackButton(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (!game) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4 animate-fade-in">
        <h1 className="text-2xl font-bold">Game Not Found</h1>
        <Link to="/games" className="text-primary-600 dark:text-primary-400 hover:underline">
          Back to Games
        </Link>
      </div>
    );
  }

  const GameComponent = GAME_COMPONENTS[game.id];

  return (
    <div className="animate-fade-in pb-safe">
      {/* Game container */}
      <div className="mx-2 sm:mx-3 mt-2">
        {GameComponent && <GameComponent gameId={game.id} />}
      </div>

      {/* Back button — hidden by default, appears on scroll */}
      <div className={`mt-8 mb-8 px-4 flex justify-center transition-opacity duration-300 ${showBackButton ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
        <Link
          to="/games"
          className="inline-flex items-center gap-1.5 text-sm text-slate-500 dark:text-slate-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors py-1 px-2 rounded-lg active:bg-slate-100 dark:active:bg-slate-800"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Games
        </Link>
      </div>
    </div>
  );
}
