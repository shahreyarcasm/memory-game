import {
  Binary,
  Grid3x3,
  Layers,
  Palette,
  MapPin,
  Zap,
} from 'lucide-react';
import type { CognitiveCategory, GameMetadata } from '../types/game';

const makeGame = (
  id: string,
  slug: string,
  title: string,
  category: CognitiveCategory,
  description: string,
  icon: string,
  lucideIcon: GameMetadata['lucideIcon'],
  color: string,
  howToPlay: string,
): GameMetadata => ({ id, slug, title, category, description, icon, lucideIcon, color, howToPlay });

export const GAMES: GameMetadata[] = [
  makeGame(
    'digit-span',
    'digit-span',
    'Digit Span',
    'working-memory',
    'Remember sequences of digits and recall them forwards or backwards. A core working-memory exercise.',
    '123',
    Binary,
    '#6366f1',
    'Watch the digits appear one at a time, then tap them in the same order. Reverse mode flips the order.',
  ),
  makeGame(
    'spatial-matrix',
    'spatial-matrix',
    'Spatial Matrix',
    'working-memory',
    'Memorize the pattern of highlighted cells, then reproduce it from memory.',
    '⊞',
    Grid3x3,
    '#0ea5e9',
    'Some cells flash on the grid. When they hide, tap the cells you saw — then check your answer.',
  ),
  makeGame(
    'card-pairs',
    'card-pairs',
    'Card Pairs',
    'spatial',
    'Flip cards two at a time and match every pair. Classic visual recognition memory.',
    '🂠',
    Layers,
    '#10b981',
    'Tap a card to flip it, then tap another to find its twin. Fewer moves means a better score.',
  ),
  makeGame(
    'stroop',
    'stroop',
    'Stroop Challenge',
    'attention',
    'The word and its color fight each other. Follow the active rule — it keeps changing on you.',
    'Aa',
    Palette,
    '#f59e0b',
    'Each round shows a rule: pick the WORD or pick the COLOR. Read the rule, then answer fast.',
  ),
  makeGame(
    'object-location',
    'object-location',
    'Object Grid',
    'recall',
    'Objects appear on a grid, then vanish. Put every object back where it belonged.',
    '⊟',
    MapPin,
    '#8b5cf6',
    'Remember where each object sat. When they hide, drag or tap objects into their original cells.',
  ),
  makeGame(
    'rapid-flash',
    'rapid-flash',
    'Rapid Flash',
    'reaction',
    'Targets pop up at random — hit them as fast as you can without clicking empty space.',
    '◉',
    Zap,
    '#f43f5e',
    'Tap each glowing target the instant it appears. Missing or clicking blanks costs points.',
  ),
];

export const CATEGORY_LABELS: Record<CognitiveCategory, string> = {
  'working-memory': 'Working Memory',
  attention: 'Attention',
  spatial: 'Spatial & Visual',
  reaction: 'Reaction Speed',
  recall: 'Recall & Association',
};

/** Solid gradient pairs — used for category identity and tab underlines. */
export const CATEGORY_COLORS: Record<CognitiveCategory, string> = {
  'working-memory': 'from-indigo-500 to-sky-500',
  attention: 'from-amber-500 to-orange-500',
  spatial: 'from-emerald-500 to-teal-500',
  reaction: 'from-rose-500 to-orange-400',
  recall: 'from-violet-500 to-fuchsia-500',
};

/** Light tinted badge classes (static strings so Tailwind can see them). */
export const CATEGORY_BADGES: Record<CognitiveCategory, string> = {
  'working-memory': 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-300',
  attention: 'bg-amber-500/10 text-amber-600 dark:text-amber-300',
  spatial: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-300',
  reaction: 'bg-rose-500/10 text-rose-600 dark:text-rose-300',
  recall: 'bg-violet-500/10 text-violet-600 dark:text-violet-300',
};
